const dbInstance = window.dbInstance;


let lastOrderNumber = localStorage.getItem('lastOrderNumber') || 0;



function checkout() {
    console.log(dbInstance);
    var firstname = document.getElementById('fname').value;
    var lastName = document.getElementById('lname').value;
    var fullName = firstname + ' ' + lastName;
    var email = document.getElementById('email').value;
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    var phonenumber = document.getElementById('phonenumber').value; //phone number
    var containslettersphonenumber = /[a-zA-Z]/.test(phonenumber); //check if phone number is a letters
    var creditnum = document.getElementById('cardid').value;
    var containsLetterscard = /[a-zA-Z]/.test(creditnum); //check if there is a letters
    var address = document.getElementById('address').value;
    var expmonth = document.getElementById('expmonth').value;
    var city = document.getElementById('city').value;
    var expyear = document.getElementById('expyear').value;
    var cvv = document.getElementById('cvv').value;
    var id = document.getElementById('id').value;
    var containsLettersid = /[a-zA-Z]/.test(id); //check if there is a letters
    var alertMsg = "";
    var cart = '';
    cart = addToCart();
    var finalcost = calculateTotal();
    // Check inputs
    if (trim(firstname) == '' &&
        trim(lastName) == '' &&
        trim(phonenumber) == '' &&
        trim(creditnum) == '' &&
        trim(id) == '' &&
        trim(cvv) == '' &&
        trim(email) == '') {
        alertMsg = "Please fill your information before checkout. \n";
    } else {
        if (trim(firstname) == '') {
            alertMsg += "Insert your first name. \n";
        }
        if (trim(lastName) == '') {
            alertMsg += "Insert your last name. \n";
        }
        if (trim(phonenumber).length != 10 || containslettersphonenumber) { //phone number  
            alertMsg += "Incorrect phone number. \n";
        }
        if (trim(creditnum).length != 16 || containsLetterscard) {
            alertMsg += "illegal number, Please re-enter credit number. \n";
        }
        if (trim(id).length != 9 || containsLettersid) {
            alertMsg += "Please re-enter your ID. \n";
        }
        if (trim(cvv).length != 3) {
            alertMsg += "Please enter CVV with 3 digits. \n";
        }
        if (cart == '') {
            alertMsg += "You cart is empty. \n";
        }
        if (!emailRegex) {
            alertMsg += "please enter a valid email. \n";
        }
    }
    if (alertMsg != '') {
        alert(alertMsg);
    } else {
        document.getElementById('res').innerHTML = "Purchase Completed. </br> Your Order Number:" + lastOrderNumber;
        dbInstance.processInfo(lastOrderNumber, id, fullName, email, phonenumber, creditnum, address, expmonth, city, expyear, cvv, cart, finalcost);
        lastOrderNumber++;
        localStorage.setItem('lastOrderNumber', lastOrderNumber);
        document.getElementById('fname').value = '';
        document.getElementById('lname').value = '';
        document.getElementById('email').value = '';
        document.getElementById('cardid').value = '';
        document.getElementById('address').value = '';
        document.getElementById('expmonth').value = '1';
        document.getElementById('city').value = '';
        document.getElementById('phonenumber').value = '';
        document.getElementById('expyear').value = '2024';
        document.getElementById('cvv').value = '';
        document.getElementById('id').value = '';
        document.getElementById('totalprice').innerHTML = '0';
		document.getElementById("totalprice2").innerText = "0";
        //clean cart
        for (var i = 1; i < 13; i++) {
            var str1 = 'size' + i.toString();
            document.getElementById(str1).value = 'XS';
            var str2 = 'item' + i.toString();
            document.getElementById(str2).checked = '';
        }
    }
}

function checkInput() {
	var cvvInput = document.getElementById("cvv");
    var cvv = cvvInput.value.trim();
    var containsLetterscvv = /[a-zA-Z]/.test(cvv); //check if there are any letters
    if (cvv.length > 3 || containsLetterscvv) {
        alert("Warning: CVV should be only 3 numbers and without letters");
        cvvInput.value = cvv.slice(0, -1);//delete last input
    }
}

function trim(str) {
    return str.replace(/^\s+|\s+$/g, '');
}

function calculateTotal() {
    var prices = [];
    var finalcost = 0;
    var value = 0;
    document.getElementById("totalprice").innerText = "0";
	document.getElementById("totalprice2").innerText = "0";
    for (var i = 1; i < 13; i++) {
        var str1 = 'item' + i.toString();
        var element = document.getElementById(str1);
        prices[i - 1] = document.getElementById(str1).checked;

        if (prices[i - 1]) {
            value = +element.value;
            finalcost += value;
            document.getElementById('totalprice').innerHTML = finalcost.toString();
            document.getElementById('totalprice2').innerHTML = finalcost.toString();

        }
    }
    return finalcost;
}

function addToCart() {
    var item = [];
    var str = '';
    var size;

    // Loop to check which items are selected 
    for (var i = 1; i < 13; i++) {
        var str1 = 'item' + i.toString();
        item[i - 1] = document.getElementById(str1).checked;
    }

    // Loop to build the string with selected items and sizes
    for (var i = 1; i < 13; i++) {
        if (item[i - 1]) {
            var str1 = 'size' + i.toString();
            size = document.getElementById(str1).value;
            str += 'Size-' + size + ' Of item' + i.toString() + '<br>';
        }
    }

    return str.trim(); 
}

function checktrack() {
    const customerTable = dbInstance.getCustomers();
    var textPrint = '';
    var orderIDCheckerValue = document.getElementById('idchecker').value.trim();
    var orderNumCheckerValue = document.getElementById('orderNumCheck').value.trim();
    var resIdElement = document.getElementById('resOrderNum');
    resIdElement.innerHTML = '';
    var alertMsgtrack = "";

    if (orderNumCheckerValue == '') {
        alertMsgtrack += "Please Enter Your Order Number";
    }
    if (orderIDCheckerValue == '') {
        alertMsgtrack += "\nPlease Enter Your Order ID";
    }
    if (alertMsgtrack != '') {
        alert(alertMsgtrack);
        return;
    }

    // Loop through customer data to find matching order
    for (var i = 0; i < customerTable.length; i++) {
        var customer = customerTable[i];
        if ((customer[0] == orderNumCheckerValue) && (customer[1] == orderIDCheckerValue)) {
            textPrint += 'ID:' + customer[1] + '<br/><br/>Name: ' + customer[2] + "<br/><br/> Email: " + customer[3] + "<br/><br/> Phone Number: " + customer[4] + "<br/><br/> Address: " + customer[6] + "<br/><br/>";
            document.getElementById('resOrderNum').innerHTML = textPrint + "Payment Credit Card: **********" + customer[5].slice(-6) + "<br/><br/>Card CVV: " + customer[10] + "<br/><br/>The items you bought:<br/> " + customer[11] + "<br/>Final Cost: " + customer[12] + "&#8362;";
            return;
        }
    }

    alert("There is no order with this ID and Number.");
}

function cancelorder1() {
    const dbInstance = window.dbInstance; 
    var orderIDCheckerValue = document.getElementById('idchecker').value.trim();
    var orderNumCheckerValue = document.getElementById('orderNumCheck').value.trim();
    var alertMsgdel = "";

    if (orderNumCheckerValue === '') {
        alertMsgdel += "Please Enter Your Order Number";
    }
    if (orderIDCheckerValue === '') {
        alertMsgdel += "\nPlease Enter Your Order ID";
    }
    if (alertMsgdel !== '') {
        alert(alertMsgdel);
        return;
    }


    const customerTable = dbInstance.getCustomers(); 
    for (let i = 0; i < customerTable.length; i++) {
        var customer = customerTable[i];
        if (customer[0] === orderNumCheckerValue && customer[1] === orderIDCheckerValue) {
            dbInstance.deleteOrder(orderNumCheckerValue); 
            document.getElementById('resOrderNum').innerHTML = 'Order Canceled.';
            return;
        }
    }
    document.getElementById('resOrderNum').innerHTML = 'There is no order with this ID and order number.';
}

function openContactPage() {
    document.location.href = "contact us.html";
}

function openContactPage1() {
    document.location.href = "size_chart.html";
}

function opentrackOrder() {
    document.location.href = "TackOrder.html";
}

function GoBack() {
    document.location.href = "project01.html";
}

function cleanForm() {
    //clean customer information
    document.getElementById('fname').value = '';
    document.getElementById('lname').value = '';
    document.getElementById('email').value = '';
    document.getElementById('cardid').value = '';
    document.getElementById('address').value = '';
    document.getElementById('expmonth').value = '1';
    document.getElementById('city').value = '';
    document.getElementById('phonenumber').value = '';
    document.getElementById('expyear').value = '2024';
    document.getElementById('cvv').value = '';
    document.getElementById('id').value = '';
    document.getElementById('totalprice').innerHTML = '0';
	document.getElementById("totalprice2").innerText = "0";
    //clean cart
    for (var i = 1; i < 13; i++) {
        var str1 = 'size' + i.toString();
        document.getElementById(str1).value = 'XS';
        var str2 = 'item' + i.toString();
        document.getElementById(str2).checked = '';
    }
    document.getElementById('res').innerHTML = '';
}

function cleanTrack() {
    //clean Track Page
	document.getElementById('idchecker').value = '';
    document.getElementById('orderNumCheck').value = '';
    document.getElementById('resOrderNum').innerHTML = '';
}