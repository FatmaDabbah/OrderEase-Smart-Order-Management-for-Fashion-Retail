class CustomerDatabase {
    constructor() {
        if (!CustomerDatabase.instance) {
            this.customers = {};
            CustomerDatabase.instance = this;
        }
        return CustomerDatabase.instance;
    }

    processInfo(lastOrderNumber, id, fullName, phoneNumber, email, creditNum, address, expMonth, city, expYear, cvv, cart, finalCost) {
        var dbStr = this.stringify(lastOrderNumber, id, fullName, email, phoneNumber, creditNum, address, expMonth, city, expYear, cvv, cart, finalCost);
        localStorage.setItem(lastOrderNumber, dbStr);
    }

    stringify(lastOrderNumber, id, fullName, email, phoneNumber, creditNum, address, expMonth, city, expYear, cvv, cart, finalCost) {
        var Idstr = 'ID: ' + id;
        var nameStr = 'name: ' + fullName;
        var emailStr = 'email: ' + email;
        var phoneStr = 'phone: ' + phoneNumber;
        var creditNumStr = 'creditnum: ' + creditNum;
        var addressStr = 'address: ' + address;
        var expMonthStr = 'expmonth: ' + expMonth;
        var cityStr = 'city: ' + city;
        var expYearStr = 'expyear: ' + expYear;
        var cvvStr = 'cvv: ' + cvv;
        var cartStr = 'cart: ' + cart;
        var finalCostStr = 'cost: ' + finalCost;
        var dbStr = '{' + Idstr + ',' + nameStr + ',' + emailStr + ',' + phoneStr + ',' + creditNumStr + ',' +
            addressStr + ',' + expMonthStr + ',' + cityStr + ',' + expYearStr + ',' + cvvStr + ',' + cartStr + ',' + finalCostStr + '}';
        return dbStr;
    }

    getCustomers() {
        var customers = [];
        for (let i = 0; i < localStorage.length; i++) {
            const customerOrderNum = localStorage.key(i);
            const tmpcustomer = [];
            const customerInfo = localStorage.getItem(customerOrderNum);
            tmpcustomer[0] = customerOrderNum;
            tmpcustomer[1] = this.getID(customerInfo);
            tmpcustomer[2] = this.getName(customerInfo);
            tmpcustomer[3] = this.getEmail(customerInfo);
            tmpcustomer[4] = this.getPhone(customerInfo);
            tmpcustomer[5] = this.getCreditnum(customerInfo);
            tmpcustomer[6] = this.getAddr(customerInfo);
            tmpcustomer[7] = this.getExpmonth(customerInfo);
            tmpcustomer[8] = this.getCity(customerInfo);
            tmpcustomer[9] = this.getExpyear(customerInfo);
            tmpcustomer[10] = this.getCvv(customerInfo);
            tmpcustomer[11] = this.getCart(customerInfo);
            tmpcustomer[12] = this.getFinalPrice(customerInfo); // Assign final price
            customers.push(tmpcustomer);
        }
        return customers;
    }

    getID(customerInfo) {
        const IdIndex = customerInfo.indexOf('ID') + 4;
        const endIdIndex = customerInfo.indexOf('name') - 1;
        return customerInfo.substring(IdIndex, endIdIndex);
    }

    getName(customerInfo) {
        const nameIndex = customerInfo.indexOf('name') + 6;
        const endNameIndex = customerInfo.indexOf('email') - 1;
        return customerInfo.substring(nameIndex, endNameIndex);
    }

    getEmail(customerInfo) {
        const emailIndex = customerInfo.indexOf('email') + 7;
        const endEmailIndex = customerInfo.indexOf('phone') - 1;
        return customerInfo.substring(emailIndex, endEmailIndex);
    }

    getPhone(customerInfo) {
        const phoneIndex = customerInfo.indexOf('phone') + 7;
        const endPhoneIndex = customerInfo.indexOf('creditnum') - 1;
        return customerInfo.substring(phoneIndex, endPhoneIndex);
    }

    getCreditnum(customerInfo) {
        const creditnumIndex = customerInfo.indexOf('creditnum') + 11;
        const endCreditnumIndex = customerInfo.indexOf('address') - 1;
        return customerInfo.substring(creditnumIndex, endCreditnumIndex);
    }

    getAddr(customerInfo) {
        const addrIndex = customerInfo.indexOf('address') + 9;
        const endAddrIndex = customerInfo.indexOf('expmonth') - 1;
        return customerInfo.substring(addrIndex, endAddrIndex);
    }

    getExpmonth(customerInfo) {
        const expmonthIndex = customerInfo.indexOf('expmonth') + 10;
        const endExpmonthIndex = customerInfo.indexOf('city') - 1;
        return customerInfo.substring(expmonthIndex, endExpmonthIndex);
    }

    getCity(customerInfo) {
        const cityIndex = customerInfo.indexOf('city') + 6;
        const endCityIndex = customerInfo.indexOf('expyear') - 1;
        return customerInfo.substring(cityIndex, endCityIndex);
    }

    getExpyear(customerInfo) {
        const expyearIndex = customerInfo.indexOf('expyear') + 9;
        const endExpyearIndex = customerInfo.indexOf('cvv') - 1;
        return customerInfo.substring(expyearIndex, endExpyearIndex);
    }

    getCvv(customerInfo) {
        const cvvIndex = customerInfo.indexOf('cvv') + 5;
        const endCvvIndex = customerInfo.indexOf('cart') - 1;
        return customerInfo.substring(cvvIndex, endCvvIndex);
    }

    getCart(customerInfo) {
        const cartIndex = customerInfo.indexOf('cart') + 6;
        const endCartIndex = customerInfo.indexOf('cost') - 1;
        return customerInfo.substring(cartIndex, endCartIndex);
    }

    getFinalPrice(customerInfo) {
        const finalpriceIndex = customerInfo.indexOf('cost') + 6;
        const endfinalpriceIndex = customerInfo.indexOf('}');
        return customerInfo.substring(finalpriceIndex, endfinalpriceIndex);
    }

    deleteOrder(orderNum) {
        localStorage.removeItem(orderNum);
    }

}

if (!window.dbInstance) {
    const dbInstance = new CustomerDatabase();
    Object.freeze(dbInstance);
    window.dbInstance = dbInstance;
}

