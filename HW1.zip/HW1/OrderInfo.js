function checkout() {
    var firstname = document.getElementById('fname').value;
    var lastName = document.getElementById('lname').value;
	var fullName=firstname+' '+lastName;
    var email = document.getElementById('email').value;
    var creditnum = document.getElementById('cardid').value;
    var address = document.getElementById('address').value;
    var expmonth = document.getElementById('expmonth').value;
    var city = document.getElementById('city').value;
    var expyear = document.getElementById('expyear').value;
    var cvv = document.getElementById('cvv').value;
    var id = document.getElementById('id').value;
    var alertMsg = "";
    var cart = '';
    cart = addToCart();
    // Check inputs
    if (trim(firstname) == '' &&
    trim(lastName) == '' &&
    trim(creditnum).length != 16 &&
    trim(id).length != 9 &&
    (expmonthvalue > 12 || expmonthvalue < 1 || trim(expmonth) == '') &&
    trim(cvv).length != 3 &&
    cart == '') {
        alertMsg = "Please fill your information before checkout. \n";
    }
    else {
        if (trim(firstname) == '') {
            alertMsg = "Insert your first name. \n";
        }
        if (trim(lastName) == '') {
            alertMsg += "Insert your last name. \n";
        }
        if (trim(creditnum).length != 16) {
            alertMsg += "illegal number, Please re-enter credit number. \n";
        }
        if (trim(id).length != 9) {
            alertMsg += "Please re-enter your ID. \n";
        }
        if (trim(cvv).length != 3) {
            alertMsg += "Please enter CVV with 3 digits. \n";
        }
        if (cart == '') {
            alertMsg += "You cart is empty. \n";
        }
    }
    if (alertMsg != '') {
        alert(alertMsg);
    } 
    else {
        document.getElementById('res').innerHTML =  "Purchase Completed." ;
		processInfo(id, fullName, email, creditnum, address, expmonth, city, expyear, cvv, cart);

    }
}

function trim(str) {
    return str.replace(/^\s+|\s+$/g, '');
}
//function to return a string of the items the customer ordered and the sizes
function addToCart() {
    var item = [];
    var str = '';
    var size;

    // Loop to check which items are selected
    for (var i = 1; i < 13; i++) {
        var str1 = 'item' + i.toString();
        item[i - 1] = document.getElementById(str1).checked;
    }

    // Loop to build the string with selected items and sizes
    for (var i = 1; i < 13; i++) {
        if (item[i - 1]) {
            var str1 = 'size' + i.toString();
            size = document.getElementById(str1).value;
            str += 'Size-' + size + ' Of item' + i.toString()+'</br>';
        }
    }


     
    return str.trim(); // Trim any leading or trailing spaces
}

//function to represent the information of an order and custmer according the id
function checktrack(){
	var customerTable = GetCustomer();
	var textPrint = '';
	document.getElementById('resId').innerHTML ='';
	if(document.getElementById('idchecker').value=='')
	{
		alert("Please Enter Your ID");
	}
	else{
		for(i=0; i<customerTable.length; i++){
			var customer = customerTable[i];
			if(customer[0]==document.getElementById('idchecker').value){
				textPrint+='Name: '+customer[1]+".<br/> Email: " + customer[2] + ".<br/> Address: " + customer[4] + ".<br/> ";
				document.getElementById('resId').innerHTML = textPrint + "Payment Credit Card: **********"  +"<br/>Card CVV: " + customer[8] + "<br/>The items you bought:<br/> "+customer[9] ;
			}
		
		}
		if(textPrint==''){
			alert("There is no order with this Id");
		}
	}
	


}


//clean form
function cleanForm(){
	//clean customer information
	document.getElementById('fname').value = '';
	document.getElementById('lname').value = '';
	document.getElementById('email').value = '';
	document.getElementById('cardid').value = '';
	document.getElementById('address').value = '';
	document.getElementById('expmonth').value = '1';
	document.getElementById('city').value = '';
	document.getElementById('expyear').value = '2024';
	document.getElementById('cvv').value = '';
	document.getElementById('idchecker').value = '';
	document.getElementById('id').value = '';
	//clean cart
	for (var i = 1; i < 13; i++) {
       var str1 = 'size' + i.toString();
	   document.getElementById(str1).value= 'XS';
	   var str2 = 'item' + i.toString();
	   document.getElementById(str2).checked = '';
    }
    document.getElementById('res').innerHTML = '' ;
	document.getElementById('resId').innerHTML = '';	
}