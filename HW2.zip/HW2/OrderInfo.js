function checkout() {
    var firstname = document.getElementById('fname').value;
    var lastName = document.getElementById('lname').value;
	var fullName=firstname+' '+lastName;
    var email = document.getElementById('email').value;
	var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    var phonenumber = document.getElementById('phonenumber').value;   //phone number
    var containslettersphonenumber = /[a-zA-z]/.test(phonenumber);  //check if phone number is a letters
    var creditnum = document.getElementById('cardid').value;
    var containsLetterscard = /[a-zA-Z]/.test(creditnum); //check if there is a letters
    var address = document.getElementById('address').value;
    var expmonth = document.getElementById('expmonth').value;
    var city = document.getElementById('city').value;
    var expyear = document.getElementById('expyear').value;
    var cvv = document.getElementById('cvv').value;
	var containsLetterscvv = /[a-zA-Z]/.test(cvv);//check if there is a letters
    var id = document.getElementById('id').value;
	var containsLettersid = /[a-zA-Z]/.test(id);//check if there is a letters
    var alertMsg = "";
    var cart = '';
    cart = addToCart();
    // Check inputs
    if (trim(firstname) == '' &&
    trim(lastName) == '' &&
    trim(phonenumber)==''&&
    trim(creditnum) =='' &&
    trim(id) =='' &&
    trim(cvv) =='' &&
	trim(email)=='') 
	{
        alertMsg = "Please fill your information before checkout. \n";
    }
    else {
        if (trim(firstname) == '') {
            alertMsg += "Insert your first name. \n";
        }
        if (trim(lastName) == '') {
            alertMsg += "Insert your last name. \n";
        }
        if (trim(phonenumber).length != 10 || containslettersphonenumber) {  //phone number  
            alertMsg += "Incorrect phone number. \n";
        }
        if (trim(creditnum).length != 16 || containsLetterscard) {
            alertMsg += "illegal number, Please re-enter credit number. \n";
        }
        if (trim(id).length != 9 || containsLettersid) {
            alertMsg += "Please re-enter your ID. \n";
        }
        if (trim(cvv).length != 3 || containsLetterscvv) {
            alertMsg += "Please enter CVV with 3 digits. \n";
        }
        if (cart == '') {
            alertMsg += "You cart is empty. \n";
        }
		if(!emailRegex){
			alertMsg += "please enter a valid email. \n";
		}
    }
    if (alertMsg != '') {
        alert(alertMsg);
    } 
    else {
        document.getElementById('res').innerHTML =  "Purchase Completed." ;
		processInfo(id, fullName, email, phonenumber, creditnum, address, expmonth, city, expyear, cvv, cart);

    }
}


function trim(str) {
    return str.replace(/^\s+|\s+$/g, '');
}
//function to return a string of the items the customer ordered and the sizes
function addToCart() {
    var item = [];
    var str = '';
    var size;

    // Loop to check which items are selected
    for (var i = 1; i < 13; i++) {
        var str1 = 'item' + i.toString();
        item[i - 1] = document.getElementById(str1).checked;
    }

    // Loop to build the string with selected items and sizes
    for (var i = 1; i < 13; i++) {
        if (item[i - 1]) {
            var str1 = 'size' + i.toString();
            size = document.getElementById(str1).value;
            str += 'Size-' + size + ' Of item' + i.toString()+'</br>';
        }
    }


     
    return str.trim(); // Trim any leading or trailing spaces
}

//function to represent the information of an order and custmer according the id
function checktrack(){
	var customerTable = GetCustomer();
	var textPrint = '';
	document.getElementById('resId').innerHTML ='';
	if(document.getElementById('idchecker').value=='')
	{
		alert("Please Enter Your ID");
	}
	else{
		for(i=0; i<customerTable.length; i++){
			var customer = customerTable[i];
			if(customer[0]==document.getElementById('idchecker').value){
				textPrint+='Name: '+customer[1]+".<br/> Email: " + customer[2] +"<br/> Phone Number: " + customer[3] + ".<br/> Address: " + customer[5] + "<br/> ";
				document.getElementById('resId').innerHTML = textPrint + "Payment Credit Card: **********"+ customer[4].slice(-6)  +"<br/>Card CVV: " + customer[9] + "<br/>The items you bought:<br/> "+customer[10] ;
			}
		
		}
		if(textPrint==''){
			alert("There is no order with this Id");
		}
	}
	


}

function cancelorder1(){
    var id = document.getElementById('idchecker').value;
    if(id != '' && id.length == 9){
        removeIdFromDb(id);
        document.getElementById('resId').innerHTML ='Order Canceled';
    }
    else alert("Incorrect Order ID");

}

function openContactPage() {
    document.location.href = "contact us.html";
}
function openContactPage1() {
    document.location.href = "size_chart.html";
}

//clean form
function cleanForm(){
	//clean customer information
	document.getElementById('fname').value = '';
	document.getElementById('lname').value = '';
	document.getElementById('email').value = '';
	document.getElementById('cardid').value = '';
	document.getElementById('address').value = '';
	document.getElementById('expmonth').value = '1';
	document.getElementById('city').value = '';
	document.getElementById('expyear').value = '2024';
	document.getElementById('cvv').value = '';
	document.getElementById('idchecker').value = '';
	document.getElementById('id').value = '';
	//clean cart
	for (var i = 1; i < 13; i++) {
       var str1 = 'size' + i.toString();
	   document.getElementById(str1).value= 'XS';
	   var str2 = 'item' + i.toString();
	   document.getElementById(str2).checked = '';
    }
    document.getElementById('res').innerHTML = '' ;
	document.getElementById('resId').innerHTML = '';	
}

