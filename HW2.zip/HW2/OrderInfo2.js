//process and store customer information in local storage
function processInfo(id, fullName, phonenumber, email, creditnum, address, expmonth, city, expyear, cvv, cart) {
    var dbstr = stringify(id, fullName, email, phonenumber, creditnum, address, expmonth, city, expyear, cvv, cart);
    localStorage.setItem(id, dbstr);
}
//create a string that represent the customer information
function stringify(id, fullName, phonenumber, email, creditnum, address, expmonth, city, expyear, cvv, cart) {
    var nameStr = 'name :' + fullName;
    var emailStr = 'email :' + email;
    var phonestr = 'phone :' + phonenumber;
    var creditnumStr = 'creditnum :' + creditnum;
    var addressStr = 'address :' + address;
    var expmonthStr = 'expmonth :' + expmonth;
    var cityStr = 'city :' + city;
    var expyearStr = 'expyear :' + expyear;
    var cvvStr = 'cvv :' + cvv;
	var cartStr='cart :'+cart;
    var dbStr = '{' + nameStr + ',' + emailStr + ',' + phonestr + ','+ creditnumStr + ',' +
        addressStr + ', ' + expmonthStr +  ', ' + cityStr + ', ' + expyearStr + ', ' + cvvStr + ', '+ cartStr +'}';
    return dbStr;
}
//get the data of the customer from the database
	function GetCustomer(){     
	var customers = [];	
	for (i = 0; i < localStorage.length; i++) {
	var customerId = localStorage.key(i);
	var tmpcustomer = [];
	var customerInfo = localStorage.getItem(customerId);
    tmpcustomer[0] = customerId;
	tmpcustomer[1] = getName(customerInfo);
    tmpcustomer[2] = getEmail(customerInfo);
    tmpcustomer[3] = getPhone(customerInfo);
    tmpcustomer[4] = getCreditnum(customerInfo);
    tmpcustomer[5] = getAddr(customerInfo);
    tmpcustomer[6] = getExpmonth(customerInfo);
    tmpcustomer[7] = getCity(customerInfo);
    tmpcustomer[8] = getExpyear(customerInfo);
    tmpcustomer[9] = getCvv(customerInfo);
	tmpcustomer[10]=getCart(customerInfo);
	customers[i]=tmpcustomer
	}
	return customers;

}
function removeIdFromDb(id){
    localStorage.removeItem(id);
}



function getName(customerInfo) {
    var NameIndex = customerInfo.indexOf('name')+6;
    var endNameIndex = customerInfo.indexOf('email') - 1;
    return customerInfo.substring(NameIndex, endNameIndex);
}

function getEmail(customerInfo) {
    var emailIndex = customerInfo.indexOf('email') + 7;
    var endEmailIndex = customerInfo.indexOf('phone') - 1;
    return customerInfo.substring(emailIndex, endEmailIndex);
}

function getPhone(customerInfo) {
    var PhoneIndex = customerInfo.indexOf('phone') + 7;                     //phone number
    var endPhoneIndex = customerInfo.indexOf('creditnum') - 1;
    return customerInfo.substring(PhoneIndex, endPhoneIndex);
}

function getCreditnum(customerInfo) {
    var creditnumIndex = customerInfo.indexOf('creditnum') + 11;
    var endCreditnumIndex = customerInfo.indexOf('address') - 1;
    return customerInfo.substring(creditnumIndex, endCreditnumIndex);
}

function getAddr(customerInfo) {
    var addrIndex = customerInfo.indexOf('address') + 9;
    var endAddrIndex = customerInfo.indexOf('expmonth') - 1;
    return customerInfo.substring(addrIndex, endAddrIndex);
}

function getExpmonth(customerInfo) {
    var expmonthIndex = customerInfo.indexOf('expmonth') + 10;
    var endExpmonthIndex = customerInfo.indexOf('city') - 1;
    return customerInfo.substring(expmonthIndex, endExpmonthIndex);
}

function getCity(customerInfo) {
    var cityIndex = customerInfo.indexOf('city') + 6;
    var endCityIndex = customerInfo.indexOf('expyear') - 1;
    return customerInfo.substring(cityIndex, endCityIndex);
}

function getExpyear(customerInfo) {
    var expyearIndex = customerInfo.indexOf('expyear') + 9;
    var endExpyearIndex = customerInfo.indexOf('cvv') - 1;
    return customerInfo.substring(expyearIndex, endExpyearIndex);
}

function getCvv(customerInfo) {
    var cvvIndex = customerInfo.indexOf('cvv') + 5;
	var endCvvIndex = customerInfo.indexOf('cart')-1;
    return customerInfo.substring(cvvIndex, endCvvIndex);
}
function getCart(customerInfo) {
    var CartIndex = customerInfo.indexOf('cart')+6;
	var endCartIndex = customerInfo.indexOf('}');
    return customerInfo.substring(CartIndex, endCartIndex);
}



